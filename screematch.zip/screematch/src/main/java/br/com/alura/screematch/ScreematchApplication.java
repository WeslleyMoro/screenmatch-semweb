package br.com.alura.screematch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScreematchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScreematchApplication.class, args);
	}

}
