package br.com.alura.screematch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreematchApplicationTests {

	@Test
	void contextLoads() {
	}

}
